package edu.psu.abington.ist.ist242;

public class Main {

    public static void main(String[] args) {
         Dealership dealership = new Dealership();
         dealership.runDealership();

    }
}
